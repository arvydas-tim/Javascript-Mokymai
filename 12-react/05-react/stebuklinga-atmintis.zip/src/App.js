import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Stebuklinga atmintis</h1>
      <button>Naujas žaidimas</button>
    </div>
  );
}

export default App;
